# Cloud_Attendance_System
Cloud based student attendance system

Architecture
---------------

![alt text](https://github.com/kujalk/Cloud_Attendance_System/blob/main/cloud2.PNG)


Developer - K.Janarthanan
